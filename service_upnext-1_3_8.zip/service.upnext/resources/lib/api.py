# -*- coding: utf-8 -*-
# GNU General Public License v2.0 (see COPYING or https://www.gnu.org/licenses/gpl-2.0.txt)

from xbmc import getInfoLabel, sleep, PLAYLIST_VIDEO, PLAYLIST_MUSIC
from utils import event, get_int, get_setting, get_setting_bool, get_setting_int, jsonrpc, log as ulog


# Episode details shown in the popup
EPISODE_PROPERTIES = ['art', 'dateadded', 'episode', 'file', 'firstaired', 'lastplayed',
                      'playcount', 'plot', 'rating', 'resume', 'runtime', 'season',
                      'showtitle', 'streamdetails', 'title', 'tvshowid', 'writer']


def credits_autoplay_deadline(data, play_time, total_time):
    """Return an opt-in playback deadline only when a credits offset is known."""
    delay = get_setting_int('autoPlayCreditsTime')
    if delay <= 0:
        return None
    try:
        offset = float(data.get('notification_offset'))
    except (TypeError, ValueError):
        return None
    if not 0 < offset < total_time:
        return None
    # An earlier notification_time may show the prompt before the credits.
    # A late prompt still gives the viewer the full configured response time.
    return min(total_time, max(play_time, offset) + delay)


def credits_chapter(play_time=None, total_time=None):
    """Name of the current chapter when it is a credits chapter, otherwise None

    Kodi only exposes the chapter that is playing right now (not the chapter list or their start times),
    so this can only notice when playback enters a credits chapter, which is exactly when the popup is wanted.
    """
    if not get_setting_bool('useChapters'):
        return None

    # Opening credits / intro chapters are also called "credits": only look in the second half of the file
    if not play_time or not total_time or play_time < total_time * 0.5:
        return None

    try:
        chapter_count = int(getInfoLabel('Player.ChapterCount') or 0)
    except ValueError:
        chapter_count = 0
    if chapter_count < 2:  # No (useful) chapters in this file, use the length based times
        return None

    # A credits chapter is never the first one, and not in the first half of the chapters
    try:
        chapter_index = int(getInfoLabel('Player.Chapter') or 0)
    except ValueError:
        chapter_index = 0
    if chapter_index and (chapter_index < 2 or chapter_index < chapter_count / 2):
        return None

    chapter_name = (getInfoLabel('Player.ChapterName') or '').strip()
    if not chapter_name:
        return None

    keywords = [keyword.strip().lower() for keyword in (get_setting('chapterKeywords') or '').split(',')]
    if any(keyword and keyword in chapter_name.lower() for keyword in keywords):
        return chapter_name
    return None


def countdown_time(total_time=None):
    """Length in seconds of the Up Next countdown, using the same episode length buckets as notification_time()"""
    if total_time and get_setting_bool('customAutoPlayTime'):
        if total_time > 60 * 60:
            return get_setting_int('autoPlayCountdownXL')
        if total_time > 40 * 60:
            return get_setting_int('autoPlayCountdownL')
        if total_time > 20 * 60:
            return get_setting_int('autoPlayCountdownM')
        if total_time > 10 * 60:
            return get_setting_int('autoPlayCountdownS')
        return get_setting_int('autoPlayCountdownXS')

    # Use one global default, regardless of episode length
    return get_setting_int('autoPlayCountdownAll')


class Api:
    """Main API class"""
    _shared_state = {}

    PLAYER_PLAYLIST = {
        'video': PLAYLIST_VIDEO,  # 1
        'audio': PLAYLIST_MUSIC   # 0
    }

    def __init__(self):
        """Constructor for Api class"""
        self.__dict__ = self._shared_state
        self.data = {}
        self.encoding = 'base64'

    def log(self, msg, level=2):
        """Log wrapper"""
        ulog(msg, name=self.__class__.__name__, level=level)

    def has_addon_data(self):
        return self.data

    def reset_addon_data(self):
        self.data = {}

    def addon_data_received(self, data, encoding='base64'):
        self.log('addon_data_received called with data %s' % data, 2)
        self.data = data
        self.encoding = encoding

    @staticmethod
    def play_kodi_item(episode):
        jsonrpc(method='Player.Open', id=0, params={'item': {'episodeid': episode.get('episodeid')}})

    @staticmethod
    def _get_playerid(playerid_cache=[None]):  # pylint: disable=dangerous-default-value
        """Function to get active player playerid"""

        # We don't need to actually get playerid everytime, cache and reuse instead
        if playerid_cache[0] is not None:
            return playerid_cache[0]

        # Sometimes Kodi gets confused and uses a music playlist for video content,
        # so get the first active player instead, default to video player.
        result = jsonrpc(method='Player.GetActivePlayers')
        result = [
            player for player in result.get('result', [{}])
            if player.get('type', 'video') in Api.PLAYER_PLAYLIST
        ]

        playerid = get_int(result[0], 'playerid') if result else -1

        if playerid == -1:
            return None

        playerid_cache[0] = playerid
        return playerid

    @staticmethod
    def get_playlistid(playlistid_cache=[None]):  # pylint: disable=dangerous-default-value
        """Function to get playlistid of active player"""

        # We don't need to actually get playlistid everytime, cache and reuse instead
        if playlistid_cache[0] is not None:
            return playlistid_cache[0]

        result = jsonrpc(
            method='Player.GetProperties',
            params={
                'playerid': Api._get_playerid(playerid_cache=[None]),
                'properties': ['playlistid'],
            }
        )
        result = get_int(
            result.get('result', {}), 'playlistid', Api.PLAYER_PLAYLIST['video']
        )

        return result

    def queue_next_item(self, episode):
        next_item = {}
        if not self.data:
            next_item.update(episodeid=episode.get('episodeid'))
        elif self.data.get('play_url'):
            next_item.update(file=self.data.get('play_url'))

        if next_item:
            jsonrpc(
                method='Playlist.Add',
                id=0,
                params={
                    'playlistid': Api.get_playlistid(),
                    'item': next_item
                }
            )

        return bool(next_item)

    @staticmethod
    def dequeue_next_item():
        """Remove unplayed next item from video playlist"""
        jsonrpc(
            method='Playlist.Remove',
            id=0,
            params={
                'playlistid': Api.get_playlistid(),
                'position': 1
            }
        )
        return False

    @staticmethod
    def reset_queue():
        """Remove previously played item from video playlist"""
        jsonrpc(
            method='Playlist.Remove',
            id=0,
            params={
                'playlistid': Api.get_playlistid(),
                'position': 0
            }
        )

    def get_next_in_playlist(self, position):
        result = jsonrpc(method='Playlist.GetItems', params={
            'playlistid': Api.get_playlistid(),
            # limits are zero indexed, position is one indexed
            'limits': {'start': position, 'end': position + 1},
            'properties': EPISODE_PROPERTIES,
        })

        item = result.get('result', {}).get('items')

        # Don't check if next item is an episode, just use it if it is there
        if not item:  # item.get('type') != 'episode':
            self.log('Error: no next item found in playlist', 1)
            return None
        item = item[0]

        # Playlist item may not have had video info details set
        # Try and populate required details if missing
        if not item.get('title'):
            item['title'] = item.get('label', '')
        item['episodeid'] = get_int(item, 'id')
        item['tvshowid'] = get_int(item, 'tvshowid')
        # If missing season/episode, change to empty string to avoid episode
        # formatting issues ("S-1E-1") in UpNext popup
        if get_int(item, 'season') == -1:
            item['season'] = ''
        if get_int(item, 'episode') == -1:
            item['episode'] = ''

        self.log('Next item in playlist: %s' % item, 2)
        return item

    def play_addon_item(self):
        if self.data.get('play_url'):
            self.log('Playing the next episode directly: %(play_url)s' % self.data, 2)
            jsonrpc(method='Player.Open', params={'item': {'file': self.data.get('play_url')}})
        else:
            message = 'Sending %(encoding)s data to add-on to play: %(play_info)s'
            self.log(message % dict(encoding=self.encoding, **self.data), 2)  # pylint: disable=use-dict-literal
            event(message=self.data.get('id'), data=self.data.get('play_info'), sender='upnextprovider', encoding=self.encoding)

    def handle_addon_lookup_of_next_episode(self):
        if not self.data:
            return None
        self.log('handle_addon_lookup_of_next_episode episode returning data %s' % self.data.get('next_episode'), 2)
        return self.data.get('next_episode')

    def handle_addon_lookup_of_current_episode(self):
        if not self.data:
            return None
        self.log('handle_addon_lookup_of_current episode returning data %s' % self.data.get('current_episode'), 2)
        return self.data.get('current_episode')

    def notification_time(self, total_time=None):
        # Alway use metadata, when available
        if self.data.get('notification_time'):
            return int(self.data.get('notification_time'))

        # Some consumers send the offset when the credits start (e.g. Netflix)
        if total_time and self.data.get('notification_offset'):
            return total_time - int(self.data.get('notification_offset'))

        # Use a customized notification time, when configured
        if total_time and get_setting_bool('customAutoPlayTime'):
            if total_time > 60 * 60:
                return get_setting_int('autoPlayTimeXL')
            if total_time > 40 * 60:
                return get_setting_int('autoPlayTimeL')
            if total_time > 20 * 60:
                return get_setting_int('autoPlayTimeM')
            if total_time > 10 * 60:
                return get_setting_int('autoPlayTimeS')
            return get_setting_int('autoPlayTimeXS')

        # Use one global default, regardless of episode length
        return get_setting_int('autoPlaySeasonTime')

    def get_now_playing(self):
        # The player can take a moment to become active, but don't wait forever
        for _ in range(10):
            result = jsonrpc(method='Player.GetActivePlayers')
            if result.get('result'):
                break
            sleep(100)
        else:
            self.log('No active player found', 1)
            return None
        self.log('Got active player %s' % result, 2)

        playerid = result.get('result')[0].get('playerid')

        # Get details of the playing media
        self.log('Getting details of now playing media', 2)
        result = jsonrpc(method='Player.GetItem', params={
            'playerid': playerid,
            'properties': ['episode', 'genre', 'playcount', 'plotoutline', 'season', 'showtitle', 'tvshowid'],
        })
        self.log('Got details of now playing media %s' % result, 2)
        return result

    def handle_kodi_lookup_of_episode(self, tvshowid, current_file, include_watched, current_episode_id):
        # Only fetch what's needed to choose, then the full details of the chosen episode
        result = jsonrpc(method='VideoLibrary.GetEpisodes', params={
            'tvshowid': tvshowid,
            'properties': ['episode', 'file', 'playcount', 'season'],
            'sort': {'method': 'episode'},
        })

        if not result.get('result'):
            return None

        self.log('Got %d episodes of the show' % len(result.get('result', {}).get('episodes', [])), 2)

        # Find the next unwatched and the newest added episodes
        episode = self.find_next_episode(result, current_file, include_watched, current_episode_id)
        if not episode:
            return None
        return self.get_episode_details(episode.get('episodeid'))

    @staticmethod
    def get_episode_details(episodeid):
        result = jsonrpc(method='VideoLibrary.GetEpisodeDetails', params={
            'episodeid': episodeid,
            'properties': EPISODE_PROPERTIES,
        })
        return result.get('result', {}).get('episodedetails')

    @staticmethod
    def showtitle_to_id(title):
        result = jsonrpc(method='VideoLibrary.GetTVShows', id='libTvShows', params={'properties': ['title']})

        for tvshow in result.get('result', {}).get('tvshows', []):
            if tvshow.get('label') == title:
                return tvshow.get('tvshowid')
        return '-1'

    @staticmethod
    def get_episode_id(showid, show_season, show_episode):
        show_season = int(show_season)
        show_episode = int(show_episode)
        result = jsonrpc(method='VideoLibrary.GetEpisodes', params={
            'properties': ['episode', 'season'],
            'tvshowid': int(showid),
            'season': show_season,
        })

        episodeid = 0
        for episode in result.get('result', {}).get('episodes', []):
            if episode.get('episodeid') and episode.get('season') == show_season and episode.get('episode') == show_episode:
                episodeid = episode.get('episodeid')

        return episodeid

    def find_next_episode(self, result, current_file, include_watched, current_episode_id):
        episodes = result.get('result', {}).get('episodes', [])

        # Put the episodes in play order (season, then episode) here, rather than relying on how Kodi sorts them
        episodes = sorted(episodes, key=lambda ep: (get_int(ep, 'season'), get_int(ep, 'episode'), get_int(ep, 'episodeid')))

        current = next((ep for ep in episodes if ep.get('episodeid') == current_episode_id), None)
        if current is None:
            self.log('No next episode found, the playing episode (%s) is not in the library' % current_episode_id, 1)
            return None

        current_season = get_int(current, 'season')
        current_library_file = current.get('file')
        next_season_allowed = get_setting_bool('playNextSeason')

        for episode in episodes[episodes.index(current) + 1:]:
            season = get_int(episode, 'season')
            if season != current_season and (current_season < 1 or not next_season_allowed):
                # Season ended. Specials (season 0) never lead into season 1, and the setting can turn
                # continuing into the next season off
                self.log('End of season %s, not continuing into season %s' % (current_season, season), 2)
                break
            # Check if it may be a multi-part episode
            if episode.get('file') in (current_file, current_library_file):
                continue
            # Skip already watched episodes?
            if not include_watched and episode.get('playcount') > 0:
                continue
            if season != current_season:
                self.log('End of season %s, next up is the first episode of season %s' % (current_season, season), 2)
            return episode

        # No next episode found
        self.log('No next episode found', 1)
        return None
